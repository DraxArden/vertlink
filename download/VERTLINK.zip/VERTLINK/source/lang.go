package main

import (
	"os"
	"path/filepath"
	"strings"
)

var italian = detectItalian()

func detectItalian() bool {
	for _, k := range []string{"LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"} {
		if v := strings.ToLower(os.Getenv(k)); v != "" {
			return strings.HasPrefix(v, "it")
		}
	}
	return systemItalian()
}

var messages = map[string][2]string{
	"running":     {"VERTLINK Agent %s · running", "VERTLINK Agent %s · attivo"},
	"token":       {"Token to enter in VERTLINK:", "Token da inserire in VERTLINK:"},
	"address":     {"Address:", "Indirizzo:"},
	"onlyHere":    {"this computer only", "solo questo computer"},
	"data":        {"Data:", "Dati:"},
	"keepOpen":    {"Keep this window open while you use VERTLINK.", "Lascia aperta questa finestra mentre usi VERTLINK."},
	"closeToStop": {"Close it (or press Ctrl+C) to stop the agent.", "Chiudila (o premi Ctrl+C) per fermare l'agente."},
	"cantStart":   {"\n  Couldn't start the agent on %s: %v\n  It may already be running in another window.\n\n", "\n  Impossibile avviare l'agente su %s: %v\n  Forse è già in esecuzione in un'altra finestra.\n\n"},
	"serverError": {"Server error:", "Errore del server:"},
	"pressEnter":  {"Press Enter to close…", "Premi Invio per chiudere…"},
	"allAdapters": {"All adapters", "Tutte le schede"},
}

func msg(k string) string {
	m := messages[k]
	if italian {
		return m[1]
	}
	return m[0]
}

// Riprende token e storico dalla versione precedente (cartella "sonda-agente").
func migrateOld(cfg string) {
	old := filepath.Join(cfg, "sonda-agente")
	if _, err := os.Stat(old); err != nil {
		return
	}
	if _, err := os.Stat(filepath.Join(dataDir, "history.jsonl")); err != nil {
		if b, err := os.ReadFile(filepath.Join(old, "storico.jsonl")); err == nil {
			_ = os.WriteFile(filepath.Join(dataDir, "history.jsonl"), b, 0o600)
			loadHistory()
		}
	}
}
