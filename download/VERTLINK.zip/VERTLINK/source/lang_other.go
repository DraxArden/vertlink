//go:build !windows

package main

import (
	"os/exec"
	"runtime"
	"strings"
)

// Su macOS il Terminale non sempre imposta LANG: leggiamo la lingua del sistema.
func systemItalian() bool {
	if runtime.GOOS == "darwin" {
		if out, err := exec.Command("defaults", "read", "-g", "AppleLanguages").Output(); err == nil {
			s := strings.ToLower(string(out))
			if i := strings.IndexAny(s, "abcdefghijklmnopqrstuvwxyz"); i >= 0 {
				return strings.HasPrefix(s[i:], "it")
			}
		}
	}
	return false
}
