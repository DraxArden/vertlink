//go:build windows

package main

import "syscall"

// Lingua dell'interfaccia di Windows: l'italiano ha identificativo primario 0x10.
func systemItalian() bool {
	proc := syscall.NewLazyDLL("kernel32.dll").NewProc("GetUserDefaultUILanguage")
	if proc.Find() != nil {
		return false
	}
	r, _, _ := proc.Call()
	return r&0x3ff == 0x10
}
