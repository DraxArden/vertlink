//go:build windows

package main

import (
	"os/exec"
	"syscall"
)

// Evita che i comandi lanciati dall'agente aprano finestre del terminale.
func hideWindow(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
}
