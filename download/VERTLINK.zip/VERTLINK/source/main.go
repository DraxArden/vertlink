// VERTLINK Agent: a small local server that gives VERTLINK (the page in the browser)
// the network data a browser cannot read on its own.
// It listens only on 127.0.0.1 and answers only clients that know the token.
package main

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"math"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const version = "1.0.0"

var (
	token    string
	dataDir  string
	started  = time.Now()
	hostname string
)

/* ---------------- utilità ---------------- */

func run(timeout time.Duration, name string, args ...string) (string, error) {
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, name, args...)
	hideWindow(cmd)
	out, err := cmd.Output()
	if ctx.Err() != nil {
		return string(out), errors.New("command timed out: " + name)
	}
	return string(out), err
}

// Su Windows forziamo l'output in UTF-8 così le lettere accentate arrivano intatte.
func runShell(timeout time.Duration, command string) (string, error) {
	if runtime.GOOS == "windows" {
		return run(timeout, "cmd", "/c", "chcp 65001 >nul & "+command)
	}
	return run(timeout, "sh", "-c", command)
}

func newToken() string {
	const abc = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	b := make([]byte, 8)
	_, _ = rand.Read(b)
	s := make([]byte, 0, 9)
	for i, x := range b {
		if i == 4 {
			s = append(s, '-')
		}
		s = append(s, abc[int(x)%len(abc)])
	}
	return string(s)
}

func loadToken() string {
	p := filepath.Join(dataDir, "token.txt")
	if b, err := os.ReadFile(p); err == nil {
		if t := strings.TrimSpace(string(b)); len(t) >= 6 {
			return t
		}
	}
	t := newToken()
	_ = os.WriteFile(p, []byte(t+"\n"), 0o600)
	return t
}

/* ---------------- traffico delle schede di rete ---------------- */

type counters map[string][2]uint64 // nome -> [ricevuti, inviati] in byte

type sample struct {
	T  int64                 `json:"t"`
	If map[string][2]float64 `json:"if"` // byte/s ricevuti e inviati
}

var (
	trafMu  sync.Mutex
	traffic []sample
	ifTotal = map[string][2]uint64{}
)

func readCounters() (counters, error) {
	c := counters{}
	switch runtime.GOOS {
	case "linux":
		b, err := os.ReadFile("/proc/net/dev")
		if err != nil {
			return nil, err
		}
		for _, line := range strings.Split(string(b), "\n") {
			i := strings.Index(line, ":")
			if i < 0 {
				continue
			}
			name := strings.TrimSpace(line[:i])
			f := strings.Fields(line[i+1:])
			if len(f) < 9 || name == "lo" {
				continue
			}
			rx, _ := strconv.ParseUint(f[0], 10, 64)
			tx, _ := strconv.ParseUint(f[8], 10, 64)
			c[name] = [2]uint64{rx, tx}
		}
	case "darwin":
		out, err := run(4*time.Second, "netstat", "-ibn")
		if err != nil {
			return nil, err
		}
		for _, line := range strings.Split(out, "\n") {
			f := strings.Fields(line)
			if len(f) < 10 || !strings.HasPrefix(f[2], "<Link#") || strings.HasPrefix(f[0], "lo") {
				continue
			}
			n := len(f)
			rx, e1 := strconv.ParseUint(f[n-5], 10, 64)
			tx, e2 := strconv.ParseUint(f[n-2], 10, 64)
			if e1 != nil || e2 != nil {
				continue
			}
			name := strings.TrimSuffix(f[0], "*")
			if _, ok := c[name]; !ok {
				c[name] = [2]uint64{rx, tx}
			}
		}
	case "windows":
		out, err := run(4*time.Second, "netstat", "-e")
		if err != nil {
			return nil, err
		}
		re := regexp.MustCompile(`(?i)^\s*bytes?\s+(\d+)\s+(\d+)`)
		for _, line := range strings.Split(out, "\n") {
			if m := re.FindStringSubmatch(line); m != nil {
				rx, _ := strconv.ParseUint(m[1], 10, 64)
				tx, _ := strconv.ParseUint(m[2], 10, 64)
				c[msg("allAdapters")] = [2]uint64{rx, tx}
				break
			}
		}
	default:
		return nil, errors.New("unsupported system")
	}
	return c, nil
}

func trafficLoop() {
	prev, _ := readCounters()
	prevT := time.Now()
	for {
		time.Sleep(time.Second)
		cur, err := readCounters()
		now := time.Now()
		if err != nil || prev == nil {
			prev, prevT = cur, now
			continue
		}
		dt := now.Sub(prevT).Seconds()
		s := sample{T: now.UnixMilli(), If: map[string][2]float64{}}
		trafMu.Lock()
		for name, v := range cur {
			p, ok := prev[name]
			if !ok || v[0] < p[0] || v[1] < p[1] { // contatore azzerato o riavviato
				continue
			}
			s.If[name] = [2]float64{math.Round(float64(v[0]-p[0]) / dt), math.Round(float64(v[1]-p[1]) / dt)}
			t := ifTotal[name]
			ifTotal[name] = [2]uint64{t[0] + v[0] - p[0], t[1] + v[1] - p[1]}
		}
		traffic = append(traffic, s)
		if len(traffic) > 3600 {
			traffic = traffic[len(traffic)-3600:]
		}
		trafMu.Unlock()
		prev, prevT = cur, now
	}
}

/* ---------------- gateway e indirizzi locali ---------------- */

var (
	gwMu    sync.Mutex
	gateway string
)

func detectGateway() string {
	var out string
	var err error
	var re *regexp.Regexp
	switch runtime.GOOS {
	case "linux":
		out, err = run(3*time.Second, "ip", "route", "show", "default")
		re = regexp.MustCompile(`default via (\d+\.\d+\.\d+\.\d+)`)
	case "darwin":
		out, err = run(3*time.Second, "route", "-n", "get", "default")
		re = regexp.MustCompile(`gateway:\s*(\d+\.\d+\.\d+\.\d+)`)
	case "windows":
		out, err = run(5*time.Second, "route", "print", "-4", "0.0.0.0")
		re = regexp.MustCompile(`(?m)^\s*0\.0\.0\.0\s+0\.0\.0\.0\s+(\d+\.\d+\.\d+\.\d+)`)
	}
	if err != nil || re == nil {
		return ""
	}
	if m := re.FindStringSubmatch(out); m != nil {
		return m[1]
	}
	return ""
}

func gatewayLoop() {
	for {
		g := detectGateway()
		gwMu.Lock()
		gateway = g
		gwMu.Unlock()
		time.Sleep(5 * time.Minute)
	}
}

func getGateway() string { gwMu.Lock(); defer gwMu.Unlock(); return gateway }

type ifaceInfo struct {
	Name  string   `json:"name"`
	Addrs []string `json:"addrs"`
	Up    bool     `json:"up"`
	MAC   string   `json:"mac"`
}

func interfaces() ([]ifaceInfo, string) {
	var list []ifaceInfo
	local := ""
	ifs, _ := net.Interfaces()
	for _, i := range ifs {
		if i.Flags&net.FlagLoopback != 0 {
			continue
		}
		ii := ifaceInfo{Name: i.Name, Up: i.Flags&net.FlagUp != 0, MAC: strings.ToUpper(i.HardwareAddr.String())}
		addrs, _ := i.Addrs()
		for _, a := range addrs {
			ii.Addrs = append(ii.Addrs, a.String())
		}
		if len(ii.Addrs) > 0 {
			list = append(list, ii)
		}
	}
	// indirizzo usato per uscire verso Internet (nessun pacchetto viene inviato)
	if c, err := net.Dial("udp", "1.1.1.1:53"); err == nil {
		local = c.LocalAddr().(*net.UDPAddr).IP.String()
		c.Close()
	}
	return list, local
}

/* ---------------- latenza continua e storico ---------------- */

type probe struct {
	t  time.Time
	ms float64 // -1 = nessuna risposta
}

var (
	latMu   sync.Mutex
	latCF   []probe
	latGW   []probe
	histMu  sync.Mutex
	history [][]any // [t, media, max, perdita, jitter, router, n]
)

func tcpRTT(addr string, timeout time.Duration, refusedOK bool) float64 {
	t0 := time.Now()
	c, err := net.DialTimeout("tcp", addr, timeout)
	el := float64(time.Since(t0).Microseconds()) / 1000
	if err == nil {
		c.Close()
		return el
	}
	// un rifiuto immediato significa che il dispositivo ha risposto
	if refusedOK && el < float64(timeout.Milliseconds())*0.9 && strings.Contains(strings.ToLower(err.Error()), "refused") {
		return el
	}
	return -1
}

func latencyLoop() {
	for {
		cf := tcpRTT("1.1.1.1:443", 2*time.Second, false)
		if cf < 0 { // seconda prova su un altro server prima di contarla come persa
			cf = tcpRTT("8.8.8.8:443", 2*time.Second, false)
		}
		var gw float64 = -2
		if g := getGateway(); g != "" {
			gw = tcpRTT(g+":80", time.Second, true)
		}
		now := time.Now()
		latMu.Lock()
		latCF = append(latCF, probe{now, cf})
		if gw > -2 {
			latGW = append(latGW, probe{now, gw})
		}
		latMu.Unlock()
		time.Sleep(2 * time.Second)
	}
}

func r1(x float64) any {
	if math.IsNaN(x) || math.IsInf(x, 0) {
		return nil
	}
	return math.Round(x*10) / 10
}

func minuteLoop() {
	for {
		now := time.Now()
		next := now.Truncate(time.Minute).Add(time.Minute + 2*time.Second)
		time.Sleep(time.Until(next))
		end := next.Truncate(time.Minute)
		start := end.Add(-time.Minute)
		latMu.Lock()
		var cf, gw []probe
		keepCF, keepGW := latCF[:0], latGW[:0]
		for _, p := range latCF {
			if !p.t.Before(start) && p.t.Before(end) {
				cf = append(cf, p)
			}
			if !p.t.Before(end) {
				keepCF = append(keepCF, p)
			}
		}
		for _, p := range latGW {
			if !p.t.Before(start) && p.t.Before(end) {
				gw = append(gw, p)
			}
			if !p.t.Before(end) {
				keepGW = append(keepGW, p)
			}
		}
		latCF, latGW = keepCF, keepGW
		latMu.Unlock()
		if len(cf) < 5 {
			continue
		}
		var ok []float64
		lost := 0
		for _, p := range cf {
			if p.ms < 0 {
				lost++
			} else {
				ok = append(ok, p.ms)
			}
		}
		row := []any{start.UnixMilli(), nil, nil, r1(float64(lost) / float64(len(cf)) * 100), nil, nil, len(cf)}
		if len(ok) > 0 {
			sum, mx, jit := 0.0, 0.0, 0.0
			for i, v := range ok {
				sum += v
				if v > mx {
					mx = v
				}
				if i > 0 {
					jit += math.Abs(v - ok[i-1])
				}
			}
			row[1], row[2] = r1(sum/float64(len(ok))), r1(mx)
			if len(ok) > 1 {
				row[4] = r1(jit / float64(len(ok)-1))
			} else {
				row[4] = 0.0
			}
		}
		var gs []float64
		for _, p := range gw {
			if p.ms >= 0 {
				gs = append(gs, p.ms)
			}
		}
		if len(gs) > 0 {
			s := 0.0
			for _, v := range gs {
				s += v
			}
			row[5] = r1(s / float64(len(gs)))
		}
		histMu.Lock()
		history = append(history, row)
		cut := time.Now().Add(-7 * 24 * time.Hour).UnixMilli()
		for len(history) > 0 && toInt64(history[0][0]) < cut {
			history = history[1:]
		}
		histMu.Unlock()
		appendHistory(row)
	}
}

func toInt64(v any) int64 {
	switch x := v.(type) {
	case int64:
		return x
	case float64:
		return int64(x)
	case json.Number:
		n, _ := x.Int64()
		return n
	}
	return 0
}

func histPath() string { return filepath.Join(dataDir, "history.jsonl") }

func appendHistory(row []any) {
	f, err := os.OpenFile(histPath(), os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0o600)
	if err != nil {
		return
	}
	defer f.Close()
	b, _ := json.Marshal(row)
	_, _ = f.Write(append(b, '\n'))
}

func loadHistory() {
	f, err := os.Open(histPath())
	if err != nil {
		return
	}
	cut := time.Now().Add(-7 * 24 * time.Hour).UnixMilli()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		var row []any
		if json.Unmarshal(sc.Bytes(), &row) == nil && len(row) == 7 && toInt64(row[0]) >= cut {
			history = append(history, row)
		}
	}
	f.Close()
	// riscrive il file tenendo solo gli ultimi 7 giorni
	tmp := histPath() + ".tmp"
	if g, err := os.Create(tmp); err == nil {
		for _, r := range history {
			b, _ := json.Marshal(r)
			_, _ = g.Write(append(b, '\n'))
		}
		g.Close()
		_ = os.Rename(tmp, histPath())
	}
}

/* ---------------- Wi-Fi ---------------- */

type wifiSnap struct {
	T   int64  `json:"t"`
	Raw string `json:"raw"`
}

var (
	wifiMu   sync.Mutex
	wifiLast wifiSnap
	wifiHist []wifiSnap
)

func readWifi() (string, error) {
	switch runtime.GOOS {
	case "windows":
		a, err := runShell(10*time.Second, "netsh wlan show interfaces")
		b, _ := runShell(15*time.Second, "netsh wlan show networks mode=bssid")
		return a + "\n" + b, err
	case "darwin":
		return run(30*time.Second, "system_profiler", "SPAirPortDataType")
	default:
		return run(10*time.Second, "nmcli", "-t", "-f", "IN-USE,SSID,BSSID,CHAN,FREQ,SIGNAL,SECURITY", "dev", "wifi", "list")
	}
}

func wifiLoop() {
	n := 0
	for {
		raw, err := readWifi()
		if err == nil && strings.TrimSpace(raw) != "" {
			s := wifiSnap{time.Now().UnixMilli(), raw}
			wifiMu.Lock()
			wifiLast = s
			if n%2 == 0 { // nello storico una lettura ogni 2 minuti, per 12 ore
				wifiHist = append(wifiHist, s)
				if len(wifiHist) > 360 {
					wifiHist = wifiHist[len(wifiHist)-360:]
				}
			}
			wifiMu.Unlock()
		}
		n++
		time.Sleep(time.Minute)
	}
}

/* ---------------- connessioni e tabella ARP ---------------- */

func readConnections() (string, map[string]string, error) {
	procs := map[string]string{}
	switch runtime.GOOS {
	case "windows":
		raw, err := run(15*time.Second, "netstat", "-ano")
		if t, e := runShell(15*time.Second, "tasklist /FO CSV /NH"); e == nil {
			re := regexp.MustCompile(`^"([^"]+)","(\d+)"`)
			for _, l := range strings.Split(t, "\n") {
				if m := re.FindStringSubmatch(strings.TrimSpace(l)); m != nil {
					procs[m[2]] = m[1]
				}
			}
		}
		return raw, procs, err
	case "darwin":
		raw, err := run(20*time.Second, "lsof", "-i", "-n", "-P")
		return raw, procs, err
	default:
		raw, err := run(15*time.Second, "ss", "-tunap")
		if err != nil {
			raw, err = run(15*time.Second, "netstat", "-tunap")
		}
		return raw, procs, err
	}
}

func readARP() (string, error) {
	if runtime.GOOS == "linux" {
		if out, err := run(5*time.Second, "ip", "neigh"); err == nil {
			return out, nil
		}
		if b, err := os.ReadFile("/proc/net/arp"); err == nil {
			return string(b), nil
		}
	}
	if runtime.GOOS == "windows" {
		return runShell(10*time.Second, "arp -a")
	}
	return run(10*time.Second, "arp", "-a")
}

/* ---------------- server HTTP ---------------- */

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	_ = json.NewEncoder(w).Encode(v)
}

func cors(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("Access-Control-Allow-Origin", "*")
		h.Set("Access-Control-Allow-Headers", "X-Vertlink-Token")
		h.Set("Access-Control-Allow-Methods", "GET, OPTIONS")
		h.Set("Access-Control-Allow-Private-Network", "true")
		h.Set("Access-Control-Max-Age", "600")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		if r.Method != http.MethodGet {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		next.ServeHTTP(w, r)
	})
}

func auth(fn http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		t := r.Header.Get("X-Vertlink-Token")
		if t == "" {
			t = r.URL.Query().Get("token")
		}
		if !strings.EqualFold(strings.TrimSpace(t), token) {
			w.WriteHeader(http.StatusUnauthorized)
			writeJSON(w, map[string]string{"errore": "missing or wrong token"})
			return
		}
		fn(w, r)
	}
}

func sinceParam(r *http.Request, def int64) int64 {
	if s := r.URL.Query().Get("since"); s != "" {
		if v, err := strconv.ParseInt(s, 10, 64); err == nil {
			return v
		}
	}
	return def
}

func main() {
	port := flag.Int("port", 8765, "local port to listen on")
	flag.Parse()

	cfg, err := os.UserConfigDir()
	if err != nil {
		cfg = "."
	}
	dataDir = filepath.Join(cfg, "vertlink-agent")
	_ = os.MkdirAll(dataDir, 0o700)
	token = loadToken()
	hostname, _ = os.Hostname()
	loadHistory()
	migrateOld(cfg)

	go trafficLoop()
	go gatewayLoop()
	go latencyLoop()
	go minuteLoop()
	go wifiLoop()

	mux := http.NewServeMux()
	mux.HandleFunc("/api/hello", func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"app": "vertlink-agent", "versione": version, "os": runtime.GOOS, "arch": runtime.GOARCH})
	})
	mux.HandleFunc("/api/status", auth(func(w http.ResponseWriter, r *http.Request) {
		ifs, local := interfaces()
		trafMu.Lock()
		tot := map[string][2]uint64{}
		for k, v := range ifTotal {
			tot[k] = v
		}
		trafMu.Unlock()
		writeJSON(w, map[string]any{"versione": version, "os": runtime.GOOS, "arch": runtime.GOARCH, "host": hostname,
			"avvio": started.UnixMilli(), "gateway": getGateway(), "ipLocale": local, "interfacce": ifs, "totali": tot, "cartella": dataDir})
	}))
	mux.HandleFunc("/api/traffic", auth(func(w http.ResponseWriter, r *http.Request) {
		since := sinceParam(r, time.Now().Add(-5*time.Minute).UnixMilli())
		trafMu.Lock()
		i := sort.Search(len(traffic), func(i int) bool { return traffic[i].T > since })
		out := append(make([]sample, 0, len(traffic)-i), traffic[i:]...)
		trafMu.Unlock()
		writeJSON(w, out)
	}))
	mux.HandleFunc("/api/history", auth(func(w http.ResponseWriter, r *http.Request) {
		since := sinceParam(r, 0)
		histMu.Lock()
		out := make([][]any, 0, len(history))
		for _, h := range history {
			if toInt64(h[0]) >= since {
				out = append(out, h)
			}
		}
		histMu.Unlock()
		writeJSON(w, out)
	}))
	mux.HandleFunc("/api/conns", auth(func(w http.ResponseWriter, r *http.Request) {
		raw, procs, err := readConnections()
		e := ""
		if err != nil {
			e = err.Error()
		}
		writeJSON(w, map[string]any{"t": time.Now().UnixMilli(), "raw": raw, "processi": procs, "errore": e})
	}))
	mux.HandleFunc("/api/arp", auth(func(w http.ResponseWriter, r *http.Request) {
		raw, err := readARP()
		e := ""
		if err != nil {
			e = err.Error()
		}
		writeJSON(w, map[string]any{"t": time.Now().UnixMilli(), "raw": raw, "errore": e})
	}))
	mux.HandleFunc("/api/wifi", auth(func(w http.ResponseWriter, r *http.Request) {
		wifiMu.Lock()
		s := wifiLast
		wifiMu.Unlock()
		writeJSON(w, s)
	}))
	mux.HandleFunc("/api/wifi/history", auth(func(w http.ResponseWriter, r *http.Request) {
		wifiMu.Lock()
		out := append(make([]wifiSnap, 0, len(wifiHist)), wifiHist...)
		wifiMu.Unlock()
		writeJSON(w, out)
	}))

	addr := fmt.Sprintf("127.0.0.1:%d", *port)
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		fmt.Printf(msg("cantStart"), addr, err)
		waitAndExit()
	}
	line := strings.Repeat("─", 52)
	fmt.Printf("\n  %s\n  "+msg("running")+"\n  %s\n\n", line, version, line)
	fmt.Printf("  "+msg("token")+"   %s\n\n", token)
	fmt.Printf("  %-12s http://%s  (%s)\n", msg("address"), addr, msg("onlyHere"))
	fmt.Printf("  %-12s %s\n\n", msg("data"), dataDir)
	fmt.Println("  " + msg("keepOpen"))
	fmt.Println("  " + msg("closeToStop"))
	fmt.Println()
	srv := &http.Server{Handler: cors(mux), ReadHeaderTimeout: 5 * time.Second}
	if err := srv.Serve(ln); err != nil {
		fmt.Println("  "+msg("serverError"), err)
		waitAndExit()
	}
}

func waitAndExit() {
	if runtime.GOOS == "windows" {
		fmt.Print("  " + msg("pressEnter"))
		_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
	}
	os.Exit(1)
}
