module vertlink-agent

go 1.24.7
