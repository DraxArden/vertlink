VERTLINK · NETWORK ANALYZER
===========================

Folder contents
---------------
vertlink.html              The dashboard. Double-click to open it in Chrome, Edge or Firefox.
                           Use the IT / EN switch at the top to change language.
agent/                     The local agent, one file per system:
  vertlink-agent-windows-amd64.exe     Windows (most PCs)
  vertlink-agent-windows-arm64.exe     Windows on ARM processors (e.g. some Surface models)
  vertlink-agent-mac-apple-silicon     Macs with M1, M2, M3, M4 chips
  vertlink-agent-mac-intel             Macs with Intel processors
  vertlink-agent-linux-amd64           Linux on PCs
  vertlink-agent-linux-arm64           Linux on ARM (e.g. Raspberry Pi 4 and 5)
source/                    The agent's source code (Go), to review or rebuild it.
LEGGIMI.txt                These instructions in Italian.

VERTLINK works without the agent too. The agent adds: real network adapter
traffic, connections and devices that refresh on their own, Wi-Fi signal over
time, and latency measurements that continue while the page is closed.


Starting the agent
------------------
WINDOWS
  1. Double-click vertlink-agent-windows-amd64.exe.
  2. If "Windows protected your PC" appears: More info > Run anyway.
  3. A window opens showing the TOKEN. Leave it open.
  To see the names of all programs: right-click > Run as administrator.

MACOS
  1. Open Terminal and go to the "agent" folder
     (type "cd ", drag the folder into the window, press Enter).
  2. Mac with Apple chip:
       chmod +x vertlink-agent-mac-apple-silicon
       xattr -d com.apple.quarantine vertlink-agent-mac-apple-silicon
       ./vertlink-agent-mac-apple-silicon
     Intel Mac: same commands with vertlink-agent-mac-intel.
  The xattr command removes the block macOS puts on unsigned downloaded files.

LINUX
       chmod +x vertlink-agent-linux-amd64
       ./vertlink-agent-linux-amd64
  With sudo you also see other users' processes.

The agent's messages follow your system language (Italian or English).


Connecting VERTLINK
-------------------
Open vertlink.html: in the Overview, "Local agent" panel, paste the token and
press Connect. You only enter it once. If the browser asks for permission to
access other services on this device, allow it.


Security and data
-----------------
- The agent only listens on this computer (http://127.0.0.1:8765) and only
  answers clients that know the token. Other devices can't reach it.
- It only reads: it doesn't change settings and doesn't send data to any server.
  To measure latency it opens brief connections to 1.1.1.1 and 8.8.8.8.
- The token and history (last 7 days) are stored in the "vertlink-agent" folder
  inside your user settings folder, shown in the agent's window.
- To stop it, just close its window.

Use network scanning and captures only on your own network, or with the
permission of whoever manages it.


Verify the files
----------------
SHA256SUMS.txt lists the SHA-256 fingerprint of every agent. Download the
agents only from https://draxarden.github.io/vertlink/ and compare:
  Windows (PowerShell):  Get-FileHash .\agent\vertlink-agent-windows-amd64.exe
  macOS:                 shasum -a 256 agent/vertlink-agent-mac-apple-silicon
  Linux:                 cd agent && sha256sum -c ../SHA256SUMS.txt

License: MIT (LICENSE.txt). VERTLINK is provided as is, without warranty.
